import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Drag {
	FirefoxDriver dr;
	@Test
	
    public void iframeHandling() throws InterruptedException
    {
		dr= new FirefoxDriver();
        dr.get("http://jqueryui.com/draggable/");
        dr.navigate().refresh();
        dr.manage().window().maximize();
        dr.switchTo().frame(0);
        String s=dr.findElement(By.xpath(".//*[@id='draggable']")).getText();
        System.out.println(s);
        dr.get("http://jqueryui.com/droppable/");
        dr.switchTo().frame(0);
        WebElement ele1=dr.findElement(By.xpath(".//*[@id='draggable']"));
        WebElement ele2=dr.findElement(By.xpath(".//*[@id='droppable']"));
        Actions ac=new Actions(dr);
        ac.dragAndDropBy(ele1, 100, 50).build().perform();
        Thread.sleep(3000);
        ac.dragAndDrop(ele1, ele2).build().perform();
        Thread.sleep(3000);
        dr.quit();
       System.out.println("My name is eapa"); 
    }

}
