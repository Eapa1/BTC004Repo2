package cross;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class loop 
{
	//loop use when same task need to be done again and again
	//loop is three kind
	//1.while
	//do---while
	//for loop
	
	//implementation of while loop
	//syntex: while(boolean condition){//statement}
		
		//example:
	@Test
		public void m1() throws InterruptedException
		{
			/*while(5<3)
			{
				System.out.println("1");
			}*/
			FirefoxDriver dr=new FirefoxDriver();
			dr.get("http://www.bankrate.com");
			dr.manage().window().maximize();
			dr.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
//			while(!dr.findElement(By.xpath(".//*[@id='brwrap']/div[2]/a[2]/img")).isDisplayed())
//			{
//				dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li[1]/a")).click();
//			}
//			
//			do{
//				System.out.println("");
//			}while(5>3);
//		try{
//			do{
//				dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li[1]/a")).click();
//			}while(!dr.findElement(By.xpath(".//*[@id='brwrap']/div[2]/a[2]/img")).isDisplayed());
//		}catch(NoSuchElementException e)
//		{
//			System.out.println(e.getMessage());
//			e.printStackTrace();
//		}
		
		
		//System.out.print("hi");
		
	//	for(initialization:condition:increment or decrement){//statement}
		
//		for(int i=1;i<=10;i=i++)
//		{
//			if(i==5)
//			{
//			continue;
//			}
//			System.out.println(i);
////		}
//			int mb=dr.findElements(By.xpath(".//*[@id='brwrap']/nav/ul/li/a")).size();
//		int sm=dr.findElements(By.xpath(".//*[@id='brwrap']/nav/ul/li[1]/div/ul/li/a")).size();
//		for(int j=1;j<=mb;j++)
//		{
//		
//		
//		for(int i=1;i<=3;i++)
//		{
//			Actions a=new Actions(dr);
//			a.moveToElement(dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li["+j+"]/a"))).perform();
//			Thread.sleep(5000);
//			dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li["+j+"]/div/ul/li["+i+"]/a")).click();
//			System.out.println(2);
//			Thread.sleep(5000);
//			dr.navigate().back();
//			
//			//Thread.sleep(5000);
//			
//		}
//		int i=1;
//		while(i<=sm)
//		{
//			Actions a=new Actions(dr);
//			a.moveToElement(dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li["+j+"]/a"))).perform();
//			Thread.sleep(5000);
//			dr.findElement(By.xpath(".//*[@id='brwrap']/nav/ul/li["+j+"]/div/ul/li["+i+"]/a")).click();
//			System.out.println(2);
//			Thread.sleep(5000);
//			dr.navigate().back();
//			i++;
//		}
//		
//		
//		}
//		
//		
		
		//syntex:for(dummy variable:real variable where u have some value){}
		List<WebElement> elements=dr.findElements(By.xpath(".//*[@id='brwrap']/nav/ul/li/a"));
		elements.get(4).click();
		List<WebElement> links=dr.findElements(By.tagName("a"));
		for(WebElement ele:elements)
		{
			if(ele.getText().equals("AUTO"))
			{
				ele.click();
			}
			System.out.println(ele.getText());
		}
		
//		for(WebElement link:links)
//		{
//			System.out.println(link.getText());
//		}
		dr.quit();
			
			
			
			
			
			
			
		}
		
		
	

}
